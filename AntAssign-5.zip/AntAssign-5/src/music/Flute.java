package music;

public class Flute {
	
	public void play() {
		System.out.println("Playing Flute");
	}

}
