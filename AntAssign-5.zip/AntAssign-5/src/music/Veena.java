package music;

public class Veena {

	public void play() {
		System.out.println("Playing Veena");
	}
}
