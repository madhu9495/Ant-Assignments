package music;

public class Guitar {
	
	public void play() {
		System.out.println("Playing Guitor");
	}

}
