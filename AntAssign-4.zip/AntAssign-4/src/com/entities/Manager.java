package com.entities;

public class Manager {
	
	   public String Managername;
	   public int age;
	   public double salary;
	   public String getManagername() {
		return Managername;
	}

	public void setManagername(String managername) {
		Managername = managername;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	

	   // This is the constructor of the class Manager
	   public Manager(String name, int age, double salary) {
	      this.Managername = name;
	      this.age =age;
	      this.salary=salary;
	   }

}
