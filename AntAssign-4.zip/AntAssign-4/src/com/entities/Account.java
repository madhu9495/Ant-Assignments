package com.entities;

class Account {
	//define variables
	public int id;
	public double balance; // balance for account
	public double annualInterestRate; //stores the current interest rate


	//no arg construtor
	Account () {
	    id = 0;
	    balance = 0.0;
	    annualInterestRate = 0.0;
	}
	Account(int newId, double newBalance, double newAnnualInterestRate) {
	    id = newId;
	    balance = newBalance;
	    annualInterestRate = newAnnualInterestRate;
	}
	//accessor/mutator methods for id, balance, and annualInterestRate
	public int getId() {
	    return id;
	}
	public double getBalance() {
	    return balance;
	}
	public double getAnnualInterestRate() {
	    return annualInterestRate;
	}
	public void setId(int newId) {
	    id = newId;
	}
	public void setBalance(double newBalance) {
	    balance = newBalance;
	}
	public void setAnnualInterestRate(double newAnnualInterestRate) {
	    annualInterestRate = newAnnualInterestRate;
	}

	//define method getMonthlyInterestRate
	double getMonthlyInterestRate() {
	    return annualInterestRate/12;
	}
	//define method withdraw
	double withdraw(double amount) {
	    return balance -= amount;
	}   
	//define method deposit
	double deposit(double amount) {
	    return balance += amount;   
	}
	
	}

